# auth

Simple authentication module.