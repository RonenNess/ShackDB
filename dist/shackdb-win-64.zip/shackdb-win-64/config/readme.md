# config

In this folder we have different config files.

## log4js.json

Loggers config (uses log4js, as implied).

## app.json

Sitirio's main config file, mainly define paths and general settings.